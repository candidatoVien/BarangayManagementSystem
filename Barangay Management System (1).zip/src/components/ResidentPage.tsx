import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

type RequestType = 'clearance' | 'certificate' | 'indigency';

interface Request {
  id: number;
  type: RequestType;
  name: string;
  address: string;
  age: string;
  purpose: string;
  status: 'pending' | 'approved' | 'declined';
  appointmentDate?: string;
  userId: number;
}

export default function ResidentPage() {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState<'welcome' | RequestType | 'announcement'>('welcome');
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    age: '',
    purpose: ''
  });
  const [userRequests, setUserRequests] = useState<Request[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('currentUser') || 'null');
    if (!user) {
      navigate('/resident-login');
      return;
    }
    setCurrentUser(user);
    
    // Pre-fill form data
    setFormData({
      name: `${user.firstName} ${user.middleInitial}. ${user.lastName} ${user.extension}`.trim(),
      address: user.address,
      age: user.age,
      purpose: ''
    });

    loadUserRequests(user.id);
    loadAnnouncements();
  }, [navigate]);

  const loadUserRequests = (userId: number) => {
    const allRequests = JSON.parse(localStorage.getItem('requests') || '[]');
    const filtered = allRequests.filter((r: Request) => r.userId === userId);
    setUserRequests(filtered);
  };

  const loadAnnouncements = () => {
    const announcementsData = JSON.parse(localStorage.getItem('announcements') || '[]');
    setAnnouncements(announcementsData);
  };

  const handleSubmitRequest = (type: RequestType) => {
    if (!formData.purpose.trim()) {
      alert('Please fill in the purpose field');
      return;
    }

    const requests = JSON.parse(localStorage.getItem('requests') || '[]');
    const newRequest: Request = {
      id: Date.now(),
      type,
      name: formData.name,
      address: formData.address,
      age: formData.age,
      purpose: formData.purpose,
      status: 'pending',
      userId: currentUser.id
    };

    requests.push(newRequest);
    localStorage.setItem('requests', JSON.stringify(requests));
    
    setFormData({ ...formData, purpose: '' });
    loadUserRequests(currentUser.id);
    alert('Request submitted successfully!');
  };

  const getRequestStatus = (type: RequestType) => {
    const typeRequests = userRequests.filter(r => r.type === type);
    if (typeRequests.length === 0) return null;
    
    const latestRequest = typeRequests[typeRequests.length - 1];
    
    if (latestRequest.status === 'pending') {
      return <div className="mt-4 p-4 bg-yellow-100 border border-yellow-400 rounded-lg">Pending......</div>;
    } else if (latestRequest.status === 'approved') {
      return (
        <div className="mt-4 p-4 bg-green-100 border border-green-400 rounded-lg">
          Request Approved! Please go to the Barangay Office on {latestRequest.appointmentDate || 'the scheduled date'} and find Ms/Mr. Secretary to get your document and Ms/Mr. Treasurer to pay if any
        </div>
      );
    } else if (latestRequest.status === 'declined') {
      return (
        <div className="mt-4 p-4 bg-red-100 border border-red-400 rounded-lg">
          Sorry! Your request was denied please try again later or Just come to the office of the Barangay
        </div>
      );
    }
  };

  const renderRequestForm = (type: RequestType, title: string) => {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-2xl mb-6 text-gray-800">{title}</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block mb-2">Name</label>
            <input
              type="text"
              value={formData.name}
              readOnly
              className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100"
            />
          </div>

          <div>
            <label className="block mb-2">Address</label>
            <input
              type="text"
              value={formData.address}
              readOnly
              className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100"
            />
          </div>

          <div>
            <label className="block mb-2">Age</label>
            <input
              type="text"
              value={formData.age}
              readOnly
              className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100"
            />
          </div>

          <div>
            <label className="block mb-2">Purpose</label>
            <input
              type="text"
              value={formData.purpose}
              onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
              placeholder="Enter purpose"
            />
          </div>

          <button
            onClick={() => handleSubmitRequest(type)}
            className="w-full bg-gray-700 hover:bg-gray-800 text-white px-6 py-3 rounded-lg transition-colors"
          >
            Submit Request
          </button>
        </div>

        {getRequestStatus(type)}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-400 flex">
      <div className="w-64 bg-gray-700 text-white p-6">
        <h2 className="text-2xl mb-8">Dashboard</h2>
        
        <div className="space-y-2">
          <button
            onClick={() => setActiveSection('clearance')}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'clearance' ? 'bg-gray-600' : 'hover:bg-gray-600'
            }`}
          >
            Barangay Clearance
          </button>
          
          <button
            onClick={() => setActiveSection('certificate')}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'certificate' ? 'bg-gray-600' : 'hover:bg-gray-600'
            }`}
          >
            Barangay Certificate
          </button>
          
          <button
            onClick={() => setActiveSection('indigency')}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'indigency' ? 'bg-gray-600' : 'hover:bg-gray-600'
            }`}
          >
            Barangay Indigency
          </button>
          
          <button
            onClick={() => {
              setActiveSection('announcement');
              loadAnnouncements();
            }}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'announcement' ? 'bg-gray-600' : 'hover:bg-gray-600'
            }`}
          >
            Announcement
          </button>
          
          <button
            onClick={() => navigate('/resident-login')}
            className="w-full text-left px-4 py-3 rounded-lg hover:bg-gray-600 transition-colors"
          >
            Back
          </button>
        </div>
      </div>

      <div className="flex-1 p-8">
        {activeSection === 'welcome' && (
          <div className="flex items-center justify-center h-full">
            <h1 className="text-4xl text-gray-800">Welcome to Barangay Management System</h1>
          </div>
        )}

        {activeSection === 'clearance' && renderRequestForm('clearance', 'Barangay Clearance Request')}
        {activeSection === 'certificate' && renderRequestForm('certificate', 'Barangay Certificate Request')}
        {activeSection === 'indigency' && renderRequestForm('indigency', 'Barangay Indigency Request')}

        {activeSection === 'announcement' && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl mb-6 text-gray-800">Announcements</h2>
            
            {announcements.length === 0 ? (
              <p className="text-gray-500">No announcements at this time.</p>
            ) : (
              <div className="space-y-4">
                {announcements.map((announcement) => (
                  <div key={announcement.id} className="p-4 border border-gray-200 rounded-lg">
                    <h3 className="text-lg mb-2">{announcement.title}</h3>
                    <p className="text-gray-700 mb-2">{announcement.content}</p>
                    <p className="text-sm text-gray-500">
                      Posted on: {new Date(announcement.date).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
