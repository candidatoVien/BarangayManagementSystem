import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function ResidentLoginPage() {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    const residents = JSON.parse(localStorage.getItem('residents') || '[]');
    const user = residents.find((r: any) => r.username === username && r.password === password);

    if (user) {
      localStorage.setItem('currentUser', JSON.stringify(user));
      navigate('/resident');
    } else {
      alert('Sorry you are not registered yet. Please register first at the Register Page');
    }
  };

  return (
    <div className="min-h-screen bg-gray-400 flex items-center justify-center">
      <div className="bg-white rounded-lg shadow-xl p-8 w-full max-w-md">
        <h1 className="text-3xl text-center mb-8 text-gray-800">Resident Login</h1>
        
        <div className="space-y-4">
          <div>
            <label className="block mb-2">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
              placeholder="Enter your username"
            />
          </div>

          <div>
            <label className="block mb-2">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
              placeholder="Enter your password"
            />
          </div>
        </div>

        <div className="flex gap-4 mt-8">
          <button
            onClick={() => navigate('/')}
            className="flex-1 bg-gray-500 hover:bg-gray-600 text-white px-6 py-3 rounded-lg transition-colors"
          >
            Back
          </button>
          <button
            onClick={handleLogin}
            className="flex-1 bg-gray-700 hover:bg-gray-800 text-white px-6 py-3 rounded-lg transition-colors"
          >
            Login
          </button>
        </div>
      </div>
    </div>
  );
}
