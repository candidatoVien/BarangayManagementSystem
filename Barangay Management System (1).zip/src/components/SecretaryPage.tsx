import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, X, Eye } from 'lucide-react';

interface Request {
  id: number;
  type: 'clearance' | 'certificate' | 'indigency';
  name: string;
  address: string;
  age: string;
  purpose: string;
  status: 'pending' | 'approved' | 'declined';
  appointmentDate?: string;
  userId: number;
}

export default function SecretaryPage() {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState<'approved' | 'draft' | 'history'>('approved');
  const [requests, setRequests] = useState<Request[]>([]);
  const [selectedRequest, setSelectedRequest] = useState<Request | null>(null);
  const [appointmentDate, setAppointmentDate] = useState('');

  useEffect(() => {
    const role = localStorage.getItem('adminRole');
    if (role !== 'secretary') {
      navigate('/admin-login');
      return;
    }
    loadRequests();
  }, [navigate]);

  const loadRequests = () => {
    const allRequests = JSON.parse(localStorage.getItem('requests') || '[]');
    setRequests(allRequests);
  };

  const handleApprove = (requestId: number) => {
    if (!appointmentDate) {
      alert('Please set an appointment date first!');
      return;
    }

    const updatedRequests = requests.map(req => 
      req.id === requestId 
        ? { ...req, status: 'approved' as const, appointmentDate }
        : req
    );
    
    localStorage.setItem('requests', JSON.stringify(updatedRequests));
    setRequests(updatedRequests);
    setAppointmentDate('');
    alert('Request approved successfully!');
  };

  const handleDecline = (requestId: number) => {
    const updatedRequests = requests.map(req => 
      req.id === requestId 
        ? { ...req, status: 'declined' as const }
        : req
    );
    
    localStorage.setItem('requests', JSON.stringify(updatedRequests));
    setRequests(updatedRequests);
    alert('Request declined.');
  };

  const approvedRequests = requests.filter(r => r.status === 'approved');
  const pendingRequests = requests.filter(r => r.status === 'pending');

  return (
    <div className="min-h-screen bg-gray-400 flex">
      <div className="w-64 bg-gray-700 text-white p-6">
        <h2 className="text-2xl mb-8">Secretary Dashboard</h2>
        
        <div className="space-y-2">
          <button
            onClick={() => setActiveSection('approved')}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'approved' ? 'bg-gray-600' : 'hover:bg-gray-600'
            }`}
          >
            Approved Request
          </button>
          
          <button
            onClick={() => setActiveSection('draft')}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'draft' ? 'bg-gray-600' : 'hover:bg-gray-600'
            }`}
          >
            Document Draft
          </button>
          
          <button
            onClick={() => setActiveSection('history')}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'history' ? 'bg-gray-600' : 'hover:bg-gray-600'
            }`}
          >
            Transaction History
          </button>
          
          <button
            onClick={() => navigate('/admin-login')}
            className="w-full text-left px-4 py-3 rounded-lg hover:bg-gray-600 transition-colors"
          >
            Back
          </button>
        </div>
      </div>

      <div className="flex-1 p-8">
        {activeSection === 'approved' && (
          <div className="space-y-8">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-2xl mb-6 text-gray-800">Approved Requests</h2>
              
              {approvedRequests.length === 0 ? (
                <p className="text-gray-500">No approved requests yet.</p>
              ) : (
                <div className="space-y-4">
                  {approvedRequests.map((request) => (
                    <div key={request.id} className="p-4 border border-green-200 bg-green-50 rounded-lg flex justify-between items-center">
                      <div>
                        <p className="capitalize"><span className="font-semibold">Type:</span> Barangay {request.type}</p>
                        <p><span className="font-semibold">Name:</span> {request.name}</p>
                        <p><span className="font-semibold">Purpose:</span> {request.purpose}</p>
                        <p><span className="font-semibold">Appointment:</span> {request.appointmentDate}</p>
                      </div>
                      <button
                        onClick={() => setSelectedRequest(request)}
                        className="px-4 py-2 bg-gray-700 hover:bg-gray-800 text-white rounded-lg flex items-center gap-2"
                      >
                        <Eye size={18} />
                        View
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-2xl mb-6 text-gray-800">Pending Requests</h2>
              
              {pendingRequests.length === 0 ? (
                <p className="text-gray-500">No pending requests.</p>
              ) : (
                <div className="space-y-4">
                  {pendingRequests.map((request) => (
                    <div key={request.id} className="p-4 border border-gray-200 rounded-lg">
                      <div className="mb-4">
                        <p className="capitalize"><span className="font-semibold">Type:</span> Barangay {request.type}</p>
                        <p><span className="font-semibold">Name:</span> {request.name}</p>
                        <p><span className="font-semibold">Address:</span> {request.address}</p>
                        <p><span className="font-semibold">Age:</span> {request.age}</p>
                        <p><span className="font-semibold">Purpose:</span> {request.purpose}</p>
                      </div>

                      <div className="mb-4">
                        <label className="block mb-2">Set Appointment Date:</label>
                        <input
                          type="date"
                          value={appointmentDate}
                          onChange={(e) => setAppointmentDate(e.target.value)}
                          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                        />
                      </div>
                      
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleApprove(request.id)}
                          className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg flex items-center gap-2"
                        >
                          <Check size={18} />
                          Approve
                        </button>
                        
                        <button
                          onClick={() => handleDecline(request.id)}
                          className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg flex items-center gap-2"
                        >
                          <X size={18} />
                          Decline
                        </button>
                        
                        <button
                          onClick={() => setSelectedRequest(request)}
                          className="px-4 py-2 bg-gray-700 hover:bg-gray-800 text-white rounded-lg flex items-center gap-2"
                        >
                          <Eye size={18} />
                          See Request
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {activeSection === 'draft' && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl mb-6 text-gray-800">Document Draft</h2>
            <p className="text-gray-500">Document templates and drafts will appear here.</p>
          </div>
        )}

        {activeSection === 'history' && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl mb-6 text-gray-800">Transaction History</h2>
            
            <div className="space-y-4">
              {requests.map((request) => (
                <div key={request.id} className="p-4 border border-gray-200 rounded-lg">
                  <p className="capitalize"><span className="font-semibold">Type:</span> Barangay {request.type}</p>
                  <p><span className="font-semibold">Name:</span> {request.name}</p>
                  <p><span className="font-semibold">Purpose:</span> {request.purpose}</p>
                  <p>
                    <span className="font-semibold">Status:</span>
                    <span className={`ml-2 px-3 py-1 rounded-full text-sm ${
                      request.status === 'approved' ? 'bg-green-100 text-green-700' :
                      request.status === 'declined' ? 'bg-red-100 text-red-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {request.status.toUpperCase()}
                    </span>
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {selectedRequest && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl text-gray-800">Request Details</h2>
              <button
                onClick={() => setSelectedRequest(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="space-y-3">
              <p className="capitalize"><span className="font-semibold">Type:</span> Barangay {selectedRequest.type}</p>
              <p><span className="font-semibold">Name:</span> {selectedRequest.name}</p>
              <p><span className="font-semibold">Address:</span> {selectedRequest.address}</p>
              <p><span className="font-semibold">Age:</span> {selectedRequest.age}</p>
              <p><span className="font-semibold">Purpose:</span> {selectedRequest.purpose}</p>
              <p>
                <span className="font-semibold">Status:</span>
                <span className={`ml-2 px-3 py-1 rounded-full text-sm ${
                  selectedRequest.status === 'approved' ? 'bg-green-100 text-green-700' :
                  selectedRequest.status === 'declined' ? 'bg-red-100 text-red-700' :
                  'bg-yellow-100 text-yellow-700'
                }`}>
                  {selectedRequest.status.toUpperCase()}
                </span>
              </p>
              {selectedRequest.appointmentDate && (
                <p><span className="font-semibold">Appointment Date:</span> {selectedRequest.appointmentDate}</p>
              )}
            </div>

            <button
              onClick={() => setSelectedRequest(null)}
              className="w-full mt-6 bg-gray-700 hover:bg-gray-800 text-white px-6 py-3 rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
