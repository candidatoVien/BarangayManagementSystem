import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, Edit, Trash2 } from 'lucide-react';

interface Resident {
  id: number;
  firstName: string;
  middleInitial: string;
  lastName: string;
  extension: string;
  username: string;
  age: string;
  birthdate: string;
  placeOfBirth: string;
  religion: string;
  civilStatus: string;
  address: string;
  cellphone: string;
  picture: string;
  registeredDate: string;
}

interface Official {
  id: number;
  firstName: string;
  middleInitial: string;
  lastName: string;
  extension: string;
  age: string;
  address: string;
  contactNumber: string;
  position: string;
  picture: string;
  registeredDate: string;
}

interface Request {
  id: number;
  type: 'clearance' | 'certificate' | 'indigency';
  name: string;
  address: string;
  age: string;
  purpose: string;
  status: 'pending' | 'approved' | 'declined';
  appointmentDate?: string;
  userId: number;
}

interface Announcement {
  id: number;
  title: string;
  content: string;
  date: string;
}

export default function CaptainPage() {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState<'welcome' | 'registerOfficial' | 'officialsProfile' | 'transactionHistory' | 'residentsProfile' | 'budget' | 'announcement'>('welcome');
  const [residents, setResidents] = useState<Resident[]>([]);
  const [officials, setOfficials] = useState<Official[]>([]);
  const [requests, setRequests] = useState<Request[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [selectedResident, setSelectedResident] = useState<Resident | null>(null);
  const [selectedOfficial, setSelectedOfficial] = useState<Official | null>(null);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  
  const [officialForm, setOfficialForm] = useState({
    firstName: '',
    middleInitial: '',
    lastName: '',
    extension: '',
    age: '',
    address: '',
    contactNumber: '',
    position: '',
    picture: ''
  });

  const [announcementForm, setAnnouncementForm] = useState({
    title: '',
    content: ''
  });

  const [budgetData, setBudgetData] = useState({
    totalBudget: '',
    allocations: [] as { category: string; amount: string }[]
  });

  useEffect(() => {
    const role = localStorage.getItem('adminRole');
    if (role !== 'captain') {
      navigate('/admin-login');
      return;
    }
    loadData();
  }, [navigate]);

  const loadData = () => {
    const residentsData = JSON.parse(localStorage.getItem('residents') || '[]');
    setResidents(residentsData);
    
    const officialsData = JSON.parse(localStorage.getItem('officials') || '[]');
    setOfficials(officialsData);
    
    const requestsData = JSON.parse(localStorage.getItem('requests') || '[]');
    setRequests(requestsData);
    
    const announcementsData = JSON.parse(localStorage.getItem('announcements') || '[]');
    setAnnouncements(announcementsData);
    
    const budgetDataStored = JSON.parse(localStorage.getItem('budget') || '{"totalBudget":"","allocations":[]}');
    setBudgetData(budgetDataStored);
  };

  const handleOfficialImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setOfficialForm({
          ...officialForm,
          picture: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRegisterOfficial = () => {
    if (!officialForm.firstName || !officialForm.lastName || !officialForm.age || !officialForm.address || !officialForm.contactNumber || !officialForm.position) {
      alert('Please fill in all required fields');
      return;
    }

    const newOfficial: Official = {
      id: Date.now(),
      ...officialForm,
      registeredDate: new Date().toISOString()
    };

    const updatedOfficials = [...officials, newOfficial];
    localStorage.setItem('officials', JSON.stringify(updatedOfficials));
    setOfficials(updatedOfficials);
    
    setOfficialForm({
      firstName: '',
      middleInitial: '',
      lastName: '',
      extension: '',
      age: '',
      address: '',
      contactNumber: '',
      position: '',
      picture: ''
    });
    
    alert('Official registered successfully!');
    setActiveSection('officialsProfile');
  };

  const handleMakeAnnouncement = () => {
    if (!announcementForm.title.trim() || !announcementForm.content.trim()) {
      alert('Please fill in all fields');
      return;
    }

    if (editingAnnouncement) {
      const updatedAnnouncements = announcements.map(a =>
        a.id === editingAnnouncement.id
          ? { ...a, title: announcementForm.title, content: announcementForm.content }
          : a
      );
      localStorage.setItem('announcements', JSON.stringify(updatedAnnouncements));
      setAnnouncements(updatedAnnouncements);
      setEditingAnnouncement(null);
      alert('Announcement updated successfully!');
    } else {
      const newAnnouncement: Announcement = {
        id: Date.now(),
        title: announcementForm.title,
        content: announcementForm.content,
        date: new Date().toISOString()
      };

      const updatedAnnouncements = [...announcements, newAnnouncement];
      localStorage.setItem('announcements', JSON.stringify(updatedAnnouncements));
      setAnnouncements(updatedAnnouncements);
      alert('Announcement posted successfully!');
    }
    
    setAnnouncementForm({ title: '', content: '' });
  };

  const handleEditAnnouncement = (announcement: Announcement) => {
    setEditingAnnouncement(announcement);
    setAnnouncementForm({
      title: announcement.title,
      content: announcement.content
    });
  };

  const handleDeleteAnnouncement = (id: number) => {
    if (confirm('Are you sure you want to delete this announcement?')) {
      const updatedAnnouncements = announcements.filter(a => a.id !== id);
      localStorage.setItem('announcements', JSON.stringify(updatedAnnouncements));
      setAnnouncements(updatedAnnouncements);
      alert('Announcement deleted successfully!');
    }
  };

  const handleSaveBudget = () => {
    localStorage.setItem('budget', JSON.stringify(budgetData));
    alert('Budget saved successfully!');
  };

  const approvedRequests = requests.filter(r => r.status === 'approved');

  return (
    <div className="min-h-screen bg-gray-400 flex">
      <div className="w-64 bg-gray-700 text-white p-6">
        <h2 className="text-2xl mb-8">Dashboard</h2>
        
        <div className="space-y-2">
          <button
            onClick={() => setActiveSection('registerOfficial')}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'registerOfficial' ? 'bg-gray-600' : 'hover:bg-gray-600'
            }`}
          >
            Register Barangay Officials
          </button>
          
          <button
            onClick={() => setActiveSection('officialsProfile')}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'officialsProfile' ? 'bg-gray-600' : 'hover:bg-gray-600'
            }`}
          >
            Barangay Official's Profile
          </button>
          
          <button
            onClick={() => setActiveSection('transactionHistory')}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'transactionHistory' ? 'bg-gray-600' : 'hover:bg-gray-600'
            }`}
          >
            Transaction History
          </button>
          
          <button
            onClick={() => setActiveSection('residentsProfile')}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'residentsProfile' ? 'bg-gray-600' : 'hover:bg-gray-600'
            }`}
          >
            Resident's Profile
          </button>
          
          <button
            onClick={() => setActiveSection('budget')}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'budget' ? 'bg-gray-600' : 'hover:bg-gray-600'
            }`}
          >
            Barangay's Budget
          </button>
          
          <button
            onClick={() => setActiveSection('announcement')}
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeSection === 'announcement' ? 'bg-gray-600' : 'hover:bg-gray-600'
            }`}
          >
            Announcement
          </button>
          
          <button
            onClick={() => navigate('/admin-login')}
            className="w-full text-left px-4 py-3 rounded-lg hover:bg-gray-600 transition-colors"
          >
            Back
          </button>
        </div>
      </div>

      <div className="flex-1 p-8">
        {activeSection === 'welcome' && (
          <div className="flex items-center justify-center h-full">
            <h1 className="text-4xl text-gray-800">Welcome Barangay Chairman!</h1>
          </div>
        )}

        {activeSection === 'registerOfficial' && (
          <div className="bg-white rounded-lg shadow-lg p-6 max-w-4xl mx-auto">
            <h2 className="text-2xl mb-6 text-gray-800">Register Barangay Official</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block mb-2">First Name</label>
                <input
                  type="text"
                  value={officialForm.firstName}
                  onChange={(e) => setOfficialForm({ ...officialForm, firstName: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                  required
                />
              </div>

              <div>
                <label className="block mb-2">Middle Initial</label>
                <input
                  type="text"
                  value={officialForm.middleInitial}
                  onChange={(e) => setOfficialForm({ ...officialForm, middleInitial: e.target.value })}
                  maxLength={1}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                />
              </div>

              <div>
                <label className="block mb-2">Last Name</label>
                <input
                  type="text"
                  value={officialForm.lastName}
                  onChange={(e) => setOfficialForm({ ...officialForm, lastName: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                  required
                />
              </div>

              <div>
                <label className="block mb-2">Extension (e.g., Jr., Sr.)</label>
                <input
                  type="text"
                  value={officialForm.extension}
                  onChange={(e) => setOfficialForm({ ...officialForm, extension: e.target.value })}
                  placeholder="If none, leave blank"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                />
              </div>

              <div>
                <label className="block mb-2">Age</label>
                <input
                  type="number"
                  value={officialForm.age}
                  onChange={(e) => setOfficialForm({ ...officialForm, age: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                  required
                />
              </div>

              <div>
                <label className="block mb-2">Contact Number</label>
                <input
                  type="tel"
                  value={officialForm.contactNumber}
                  onChange={(e) => setOfficialForm({ ...officialForm, contactNumber: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                  required
                />
              </div>

              <div>
                <label className="block mb-2">Position</label>
                <select
                  value={officialForm.position}
                  onChange={(e) => setOfficialForm({ ...officialForm, position: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                  required
                >
                  <option value="">Select Position</option>
                  <option value="Barangay Kagawad">Barangay Kagawad</option>
                  <option value="Secretary">Secretary</option>
                  <option value="Treasurer">Treasurer</option>
                  <option value="Auditor">Auditor</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block mb-2">Address</label>
                <input
                  type="text"
                  value={officialForm.address}
                  onChange={(e) => setOfficialForm({ ...officialForm, address: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                  required
                />
              </div>

              <div className="md:col-span-2">
                <label className="block mb-2">Upload Picture</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleOfficialImageUpload}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                />
                {officialForm.picture && (
                  <img src={officialForm.picture} alt="Preview" className="mt-4 w-32 h-32 object-cover rounded-lg" />
                )}
              </div>
            </div>

            <div className="flex gap-4 mt-8">
              <button
                onClick={() => setActiveSection('welcome')}
                className="flex-1 bg-gray-500 hover:bg-gray-600 text-white px-6 py-3 rounded-lg transition-colors"
              >
                Back
              </button>
              <button
                onClick={handleRegisterOfficial}
                className="flex-1 bg-gray-700 hover:bg-gray-800 text-white px-6 py-3 rounded-lg transition-colors"
              >
                Register
              </button>
            </div>
          </div>
        )}

        {activeSection === 'officialsProfile' && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl mb-6 text-gray-800">Barangay Official's Profile</h2>
            
            {officials.length === 0 ? (
              <p className="text-gray-500">No registered officials yet.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {officials.map((official) => (
                  <div key={official.id} className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                    {official.picture && (
                      <img 
                        src={official.picture} 
                        alt={official.firstName}
                        className="w-24 h-24 object-cover rounded-full mx-auto mb-3"
                      />
                    )}
                    <h3 className="text-center mb-2">
                      {official.firstName} {official.middleInitial}. {official.lastName} {official.extension}
                    </h3>
                    <p className="text-sm text-gray-600 text-center mb-1">{official.position}</p>
                    <p className="text-sm text-gray-600 text-center mb-3">{official.address}</p>
                    <button
                      onClick={() => setSelectedOfficial(official)}
                      className="w-full px-4 py-2 bg-gray-700 hover:bg-gray-800 text-white rounded-lg flex items-center justify-center gap-2"
                    >
                      <Eye size={18} />
                      View Profile
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeSection === 'transactionHistory' && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl mb-6 text-gray-800">Transaction History</h2>
            
            {approvedRequests.length === 0 ? (
              <p className="text-gray-500">No approved requests yet.</p>
            ) : (
              <div className="space-y-4">
                {approvedRequests.map((request) => (
                  <div key={request.id} className="p-4 border border-gray-200 rounded-lg">
                    <p className="capitalize"><span className="font-semibold">Type:</span> Barangay {request.type}</p>
                    <p><span className="font-semibold">Name:</span> {request.name}</p>
                    <p><span className="font-semibold">Address:</span> {request.address}</p>
                    <p><span className="font-semibold">Age:</span> {request.age}</p>
                    <p><span className="font-semibold">Purpose:</span> {request.purpose}</p>
                    <p><span className="font-semibold">Appointment Date:</span> {request.appointmentDate}</p>
                    <p>
                      <span className="font-semibold">Status:</span>
                      <span className="ml-2 px-3 py-1 rounded-full text-sm bg-green-100 text-green-700">
                        APPROVED
                      </span>
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeSection === 'residentsProfile' && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl mb-6 text-gray-800">Resident's Profile</h2>
            
            {residents.length === 0 ? (
              <p className="text-gray-500">No registered residents yet.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {residents.map((resident) => (
                  <div key={resident.id} className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                    {resident.picture && (
                      <img 
                        src={resident.picture} 
                        alt={resident.firstName}
                        className="w-24 h-24 object-cover rounded-full mx-auto mb-3"
                      />
                    )}
                    <h3 className="text-center mb-2">
                      {resident.firstName} {resident.middleInitial}. {resident.lastName} {resident.extension}
                    </h3>
                    <p className="text-sm text-gray-600 text-center mb-3">{resident.address}</p>
                    <button
                      onClick={() => setSelectedResident(resident)}
                      className="w-full px-4 py-2 bg-gray-700 hover:bg-gray-800 text-white rounded-lg flex items-center justify-center gap-2"
                    >
                      <Eye size={18} />
                      View Profile
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeSection === 'budget' && (
          <div className="bg-white rounded-lg shadow-lg p-6 max-w-4xl mx-auto">
            <h2 className="text-2xl mb-6 text-gray-800">Barangay's Budget</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block mb-2">Total Budget</label>
                <input
                  type="number"
                  value={budgetData.totalBudget}
                  onChange={(e) => setBudgetData({ ...budgetData, totalBudget: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                  placeholder="Enter total budget"
                />
              </div>

              <div>
                <h3 className="mb-3">Budget Allocations</h3>
                <button
                  onClick={() => {
                    setBudgetData({
                      ...budgetData,
                      allocations: [...budgetData.allocations, { category: '', amount: '' }]
                    });
                  }}
                  className="mb-4 px-4 py-2 bg-gray-700 hover:bg-gray-800 text-white rounded-lg"
                >
                  Add Allocation
                </button>

                {budgetData.allocations.map((allocation, index) => (
                  <div key={index} className="flex gap-4 mb-4">
                    <input
                      type="text"
                      value={allocation.category}
                      onChange={(e) => {
                        const newAllocations = [...budgetData.allocations];
                        newAllocations[index].category = e.target.value;
                        setBudgetData({ ...budgetData, allocations: newAllocations });
                      }}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                      placeholder="Category"
                    />
                    <input
                      type="number"
                      value={allocation.amount}
                      onChange={(e) => {
                        const newAllocations = [...budgetData.allocations];
                        newAllocations[index].amount = e.target.value;
                        setBudgetData({ ...budgetData, allocations: newAllocations });
                      }}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                      placeholder="Amount"
                    />
                    <button
                      onClick={() => {
                        const newAllocations = budgetData.allocations.filter((_, i) => i !== index);
                        setBudgetData({ ...budgetData, allocations: newAllocations });
                      }}
                      className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>

              <button
                onClick={handleSaveBudget}
                className="w-full bg-gray-700 hover:bg-gray-800 text-white px-6 py-3 rounded-lg transition-colors"
              >
                Save Budget
              </button>
            </div>
          </div>
        )}

        {activeSection === 'announcement' && (
          <div className="bg-white rounded-lg shadow-lg p-6 max-w-4xl mx-auto">
            <h2 className="text-2xl mb-6 text-gray-800">{editingAnnouncement ? 'Edit' : 'Make'} Announcement</h2>
            
            <div className="space-y-4 mb-8">
              <div>
                <label className="block mb-2">Announcement Title</label>
                <input
                  type="text"
                  value={announcementForm.title}
                  onChange={(e) => setAnnouncementForm({ ...announcementForm, title: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                  placeholder="Enter announcement title"
                />
              </div>

              <div>
                <label className="block mb-2">Announcement Content</label>
                <textarea
                  value={announcementForm.content}
                  onChange={(e) => setAnnouncementForm({ ...announcementForm, content: e.target.value })}
                  rows={6}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
                  placeholder="Enter announcement details"
                />
              </div>

              <div className="flex gap-4">
                {editingAnnouncement && (
                  <button
                    onClick={() => {
                      setEditingAnnouncement(null);
                      setAnnouncementForm({ title: '', content: '' });
                    }}
                    className="flex-1 bg-gray-500 hover:bg-gray-600 text-white px-6 py-3 rounded-lg transition-colors"
                  >
                    Cancel
                  </button>
                )}
                <button
                  onClick={handleMakeAnnouncement}
                  className="flex-1 bg-gray-700 hover:bg-gray-800 text-white px-6 py-3 rounded-lg transition-colors"
                >
                  {editingAnnouncement ? 'Update' : 'Post'} Announcement
                </button>
              </div>
            </div>

            <div>
              <h3 className="text-xl mb-4">Posted Announcements</h3>
              {announcements.length === 0 ? (
                <p className="text-gray-500">No announcements posted yet.</p>
              ) : (
                <div className="space-y-4">
                  {announcements.map((announcement) => (
                    <div key={announcement.id} className="p-4 border border-gray-200 rounded-lg">
                      <h4 className="mb-2">{announcement.title}</h4>
                      <p className="text-gray-700 mb-2">{announcement.content}</p>
                      <p className="text-sm text-gray-500 mb-3">
                        Posted on: {new Date(announcement.date).toLocaleDateString()}
                      </p>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEditAnnouncement(announcement)}
                          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center gap-2"
                        >
                          <Edit size={18} />
                          Edit
                        </button>
                        <button
                          onClick={() => handleDeleteAnnouncement(announcement.id)}
                          className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg flex items-center gap-2"
                        >
                          <Trash2 size={18} />
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {selectedResident && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl text-gray-800">Resident Profile</h2>
              <button
                onClick={() => setSelectedResident(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
            
            {selectedResident.picture && (
              <img 
                src={selectedResident.picture} 
                alt={selectedResident.firstName}
                className="w-32 h-32 object-cover rounded-full mx-auto mb-6"
              />
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="font-semibold">First Name:</p>
                <p className="text-gray-700">{selectedResident.firstName}</p>
              </div>
              <div>
                <p className="font-semibold">Middle Initial:</p>
                <p className="text-gray-700">{selectedResident.middleInitial}</p>
              </div>
              <div>
                <p className="font-semibold">Last Name:</p>
                <p className="text-gray-700">{selectedResident.lastName}</p>
              </div>
              <div>
                <p className="font-semibold">Extension:</p>
                <p className="text-gray-700">{selectedResident.extension || 'N/A'}</p>
              </div>
              <div>
                <p className="font-semibold">Age:</p>
                <p className="text-gray-700">{selectedResident.age}</p>
              </div>
              <div>
                <p className="font-semibold">Birthdate:</p>
                <p className="text-gray-700">{selectedResident.birthdate}</p>
              </div>
              <div>
                <p className="font-semibold">Place of Birth:</p>
                <p className="text-gray-700">{selectedResident.placeOfBirth}</p>
              </div>
              <div>
                <p className="font-semibold">Religion:</p>
                <p className="text-gray-700">{selectedResident.religion}</p>
              </div>
              <div>
                <p className="font-semibold">Civil Status:</p>
                <p className="text-gray-700">{selectedResident.civilStatus}</p>
              </div>
              <div>
                <p className="font-semibold">Cellphone:</p>
                <p className="text-gray-700">{selectedResident.cellphone}</p>
              </div>
              <div className="md:col-span-2">
                <p className="font-semibold">Address:</p>
                <p className="text-gray-700">{selectedResident.address}</p>
              </div>
              <div className="md:col-span-2">
                <p className="font-semibold">Registered Date:</p>
                <p className="text-gray-700">{new Date(selectedResident.registeredDate).toLocaleString()}</p>
              </div>
            </div>

            <button
              onClick={() => setSelectedResident(null)}
              className="w-full mt-6 bg-gray-700 hover:bg-gray-800 text-white px-6 py-3 rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {selectedOfficial && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl text-gray-800">Official Profile</h2>
              <button
                onClick={() => setSelectedOfficial(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
            
            {selectedOfficial.picture && (
              <img 
                src={selectedOfficial.picture} 
                alt={selectedOfficial.firstName}
                className="w-32 h-32 object-cover rounded-full mx-auto mb-6"
              />
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="font-semibold">First Name:</p>
                <p className="text-gray-700">{selectedOfficial.firstName}</p>
              </div>
              <div>
                <p className="font-semibold">Middle Initial:</p>
                <p className="text-gray-700">{selectedOfficial.middleInitial}</p>
              </div>
              <div>
                <p className="font-semibold">Last Name:</p>
                <p className="text-gray-700">{selectedOfficial.lastName}</p>
              </div>
              <div>
                <p className="font-semibold">Extension:</p>
                <p className="text-gray-700">{selectedOfficial.extension || 'N/A'}</p>
              </div>
              <div>
                <p className="font-semibold">Age:</p>
                <p className="text-gray-700">{selectedOfficial.age}</p>
              </div>
              <div>
                <p className="font-semibold">Contact Number:</p>
                <p className="text-gray-700">{selectedOfficial.contactNumber}</p>
              </div>
              <div>
                <p className="font-semibold">Position:</p>
                <p className="text-gray-700">{selectedOfficial.position}</p>
              </div>
              <div className="md:col-span-2">
                <p className="font-semibold">Address:</p>
                <p className="text-gray-700">{selectedOfficial.address}</p>
              </div>
              <div className="md:col-span-2">
                <p className="font-semibold">Registered Date:</p>
                <p className="text-gray-700">{new Date(selectedOfficial.registeredDate).toLocaleString()}</p>
              </div>
            </div>

            <button
              onClick={() => setSelectedOfficial(null)}
              className="w-full mt-6 bg-gray-700 hover:bg-gray-800 text-white px-6 py-3 rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
