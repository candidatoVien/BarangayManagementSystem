import { useNavigate } from 'react-router-dom';

export default function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-400 flex flex-col">
      <div className="w-full bg-gray-700 text-white py-8 text-center shadow-lg">
        <h1 className="text-4xl">Barangay Management System</h1>
      </div>
      
      <div className="flex-1 flex items-center justify-center">
        <div className="flex flex-col gap-6">
          <button
            onClick={() => navigate('/resident-login')}
            className="w-64 bg-gray-600 hover:bg-gray-700 text-white px-8 py-4 rounded-lg shadow-lg transition-all transform hover:scale-105"
          >
            Resident
          </button>
          <button
            onClick={() => navigate('/register')}
            className="w-64 bg-gray-600 hover:bg-gray-700 text-white px-8 py-4 rounded-lg shadow-lg transition-all transform hover:scale-105"
          >
            Register
          </button>
          <button
            onClick={() => navigate('/admin-login')}
            className="w-64 bg-gray-600 hover:bg-gray-700 text-white px-8 py-4 rounded-lg shadow-lg transition-all transform hover:scale-105"
          >
            Admin
          </button>
        </div>
      </div>
    </div>
  );
}
