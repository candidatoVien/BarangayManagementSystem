import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './components/HomePage';
import RegisterPage from './components/RegisterPage';
import ResidentLoginPage from './components/ResidentLoginPage';
import ResidentPage from './components/ResidentPage';
import AdminLoginPage from './components/AdminLoginPage';
import SecretaryPage from './components/SecretaryPage';
import CaptainPage from './components/CaptainPage';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/resident-login" element={<ResidentLoginPage />} />
        <Route path="/resident" element={<ResidentPage />} />
        <Route path="/admin-login" element={<AdminLoginPage />} />
        <Route path="/secretary" element={<SecretaryPage />} />
        <Route path="/captain" element={<CaptainPage />} />
      </Routes>
    </Router>
  );
}
