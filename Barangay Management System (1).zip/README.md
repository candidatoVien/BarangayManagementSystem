
  # Barangay Management System

  This is a code bundle for Barangay Management System. The original project is available at https://www.figma.com/design/2vq0FgAReZW2FnX1jfP8JB/Barangay-Management-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  